<?php

namespace Srapid\Base\Events;

abstract class Event
{
    //
}
